package com.db.hackathon.model;

import java.util.Date;

public class Donate {
	private	int	firm_id;
	private	int cause_id;
	private double donation_amount;
	private Date donation_date;
	public int getFirm_id() {
		return firm_id;
	}
	public void setFirm_id(int firm_id) {
		this.firm_id = firm_id;
	}
	public int getCause_id() {
		return cause_id;
	}
	public void setCause_id(int cause_id) {
		this.cause_id = cause_id;
	}
	public double getDonation_amount() {
		return donation_amount;
	}
	public void setDonation_amount(double donation_amount) {
		this.donation_amount = donation_amount;
	}
	public Date getDonation_date() {
		return donation_date;
	}
	public void setDonation_date(Date donation_date) {
		this.donation_date = donation_date;
	}
	
	
	


}
