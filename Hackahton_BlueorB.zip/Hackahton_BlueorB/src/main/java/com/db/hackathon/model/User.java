package com.db.hackathon.model;

public class User {

	private		String	email;
	private 	int		electricity;
	private 	int		natural_gas;
	private		int 	heating_oil;
	private		int		coal;
	private		int 	 propane;
	private		int		wood;
	
	private 	String	vehicle_type;
	private		int 	mileage;
	private		int		lpg;
	private		int  	water_usage;
	private		int	diet;
	
	private		int	dairy;
	private		int	fruit;
	private		int	snaks;
	
	private		int	drinks;
	
	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getElectricity() {
		return electricity;
	}

	public void setElectricity(int electricity) {
		this.electricity = electricity;
	}

	public int getNatural_gas() {
		return natural_gas;
	}

	public void setNatural_gas(int natural_gas) {
		this.natural_gas = natural_gas;
	}

	public int getHeating_oil() {
		return heating_oil;
	}

	public void setHeating_oil(int heating_oil) {
		this.heating_oil = heating_oil;
	}

	public int getCoal() {
		return coal;
	}

	public void setCoal(int coal) {
		this.coal = coal;
	}

	public int getPropane() {
		return propane;
	}

	public void setPropane(int propane) {
		this.propane = propane;
	}

	public int getWood() {
		return wood;
	}

	public void setWood(int wood) {
		this.wood = wood;
	}

	public String getVehicle_type() {
		return vehicle_type;
	}

	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

	public int getLpg() {
		return lpg;
	}

	public void setLpg(int lpg) {
		this.lpg = lpg;
	}

	public int getWater_usage() {
		return water_usage;
	}

	public void setWater_usage(int water_usage) {
		this.water_usage = water_usage;
	}

	public int getDiet() {
		return diet;
	}

	public void setDiet(int diet) {
		this.diet = diet;
	}

	public int getDairy() {
		return dairy;
	}

	public void setDairy(int dairy) {
		this.dairy = dairy;
	}

	public int getFruit() {
		return fruit;
	}

	public void setFruit(int fruit) {
		this.fruit = fruit;
	}

	public int getSnaks() {
		return snaks;
	}

	public void setSnaks(int snaks) {
		this.snaks = snaks;
	}

	public int getDrinks() {
		return drinks;
	}

	public void setDrinks(int drinks) {
		this.drinks = drinks;
	}

	
}