package com.db.hackathon.model;

import java.util.Date;

public class Invester {
	
	private String investor_name;
	private	String investor_email;
	
	public String getInvestor_name() {
		return investor_name;
	}
	public void setInvestor_name(String investor_name) {
		this.investor_name = investor_name;
	}
	public String getInvestor_email() {
		return investor_email;
	}
	public void setInvestor_email(String investor_email) {
		this.investor_email = investor_email;
	}
	
	
	
}
