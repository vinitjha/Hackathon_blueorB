//Carbon Independent
var inmenu=false;
var lastmenu=0;

var myBackgroundColor = "rgb( 85%, 93%, 79%)" ; //was 090
var myTextColor = "rgb( 13%, 25%, 0%)" ;
var myHighlightBackgroundColor = "rgb(100%, 100%, 100%)" ;
var myHighlightTextColor = "rgb( 13%, 25%, 0%)" ;

function Menu(current) {
   if (!document.getElementById) return;
   inmenu=true;
   oldmenu=lastmenu;
   lastmenu=current;
   if (oldmenu) Erase(oldmenu);
   m=document.getElementById("menu-" + current); //i.e. the top menu item
   n=document.getElementById("navbar"); //my addition
   p=document.getElementById("mainTable"); //my addition
   box=document.getElementById(current); //i.e. the drop-down box below the top menu item
   box.style.left= m.offsetLeft +n.offsetLeft +p.offsetLeft +1; //n... added by me ;
   box.style.top= m.offsetTop + m.offsetHeight + n.offsetTop +p.offsetTop ; //n... added by me
   box.style.visibility="visible";
   m.style.backgroundColor= myHighlightBackgroundColor ;
   m.style.color= myHighlightTextColor ; //added by me
   box.style.backgroundColor= myBackgroundColor ;
}

function Erase(current) {
   if (!document.getElementById) return;
   if (inmenu && lastmenu==current) {
	  return;
   }
   m=document.getElementById("menu-" + current);
   box=document.getElementById(current);
   box.style.visibility="hidden";
   m.style.backgroundColor= myBackgroundColor ; //was "Silver";
   m.style.color= myTextColor ; //added by me
}

function Timeout(current) {
   inmenu=false;
   window.setTimeout("Erase('" + current + "');", 300); //was 500 - 100 tried but too temperamental
}

function Highlight(menu,item) {
   if (!document.getElementById) return;
   inmenu=true;
   lastmenu=menu;
   obj=document.getElementById(item);
   obj.style.backgroundColor= myHighlightBackgroundColor ;
   obj.style.color= myHighlightTextColor ; //added by me
}

function UnHighlight(menu,item) {
   if (!document.getElementById) return;
   Timeout(menu);
   obj=document.getElementById(item);
   obj.style.backgroundColor= myBackgroundColor ; //was "Aqua";
   obj.style.color= myTextColor ; //added by me
}

function LoadEvents() { //added by me
   obj.style.color= myTextColor ; //added by me
}
