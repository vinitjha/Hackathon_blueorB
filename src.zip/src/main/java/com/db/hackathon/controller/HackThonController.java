package com.db.hackathon.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/*import org.springframework.ui.web.bind.annotation.PostMapping;
import org.springframework.ui.web.bind.annotation.RequestParam;*/
import org.springframework.web.servlet.ModelAndView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;


import com.db.hackathon.model.Login;
import com.db.hackathon.model.Registration;
import com.db.hackathon.model.User;


@Controller
public class HackThonController {
	
	/*@Autowired
	private HackathonApplicationDAO hackathonApplicationDAO;
	
*/
   @RequestMapping("/")
   public String root() {
      return "index";
   }
 
   @RequestMapping("/index")
   public String index() {
      return "index";
   }
   @RequestMapping("/login")
   public String login() {
      return "login";
   }
   @RequestMapping("/invest")
   public String invest() {
      return "invest";
   }
  /* @RequestMapping("/investsubmit")
   public String investSubmit() {
      return "invest";
   }*/
   @RequestMapping("/registration")
   public String register() {
      return "registration";
   }
   @RequestMapping("/carbon")
   public String carbon() {
      return "carbon_cal";
   }
   @RequestMapping("/donate")
   public String donate() {
      return "donate";
   }
  /* @RequestMapping("/donateSubmit")
   public String donatesubmit() {
      return "donate";
   }*/
   @RequestMapping("/carbonCal")
   public String carbon_val(){
	   /*System.out.println(user.getEmail());
	   System.out.println("helloooo --->" + user.getElectricity());
	   Connection c = null;
	   Statement stmt = null;
	   int user_id = 0;

	   try {
		   System.out.println("In try block");
		   //connect to the database
		   c = DriverManager.getConnection("jdbc:postgresql://juggernauts.postgres.database.azure.com:5432/postgres?user=app_owner@juggernauts&password=app_owner#&sslmode=require");

		   System.out.println("connection established");
		   
		   final String SQL_FIND = "select user_id from user_account where user_name ='"+ user.getEmail()+"'";
		   System.out.println(SQL_FIND);
		   stmt = c.createStatement();
		   ResultSet rs = stmt.executeQuery(SQL_FIND);
		   if(rs.next()) {
			  user_id = rs.getInt("user_id");
		   }







		   
		   final String SQL_INSERT_HOUSE = "INSERT INTO user_house (id, userid, created, electricity, natural_gas, heating_oil, coal, propane, wood) VALUES (nextval('serial'),?,?,?,?,?,?,?,?)";
		   PreparedStatement prepared_stmt_h = c.prepareStatement(SQL_INSERT_HOUSE);		   
		   
		   // user_house
		   prepared_stmt_h.setInt(1, user_id);
		   prepared_stmt_h.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
		   prepared_stmt_h.setInt(3, user.getElectricity());
		   prepared_stmt_h.setInt(4, user.getNatural_gas());
		   prepared_stmt_h.setInt(5, user.getHeating_oil());
		   prepared_stmt_h.setInt(6, user.getCoal());
		   prepared_stmt_h.setInt(7, user.getPropane());
		   prepared_stmt_h.setInt(8, user.getWood());
		   int row_h = prepared_stmt_h.executeUpdate();
		   System.out.println(row_h);
		   
		   // user_transport
		   final String SQL_INSERT_TRANSPORT = "INSERT INTO user_transport (id, userid, created, vehicle_type, Mileage, LPG) VALUES (nextval('serial'),?,?,?,?,?)";
		   PreparedStatement prepared_stmt_t = c.prepareStatement(SQL_INSERT_TRANSPORT);
		   prepared_stmt_t.setInt(1, user_id);
		   prepared_stmt_t.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
		   prepared_stmt_t.setString(3, user.getVehicle_type());
		   prepared_stmt_t.setInt(4, user.getMileage());
		   prepared_stmt_t.setInt(5, user.getLpg());
		   int row_t = prepared_stmt_t.executeUpdate();
		   System.out.println(row_t);
		   
		   
		   // user_personal
		   final String SQL_INSERT_PERSONAL = "INSERT INTO user_personal (id, userid, created, water_usage, diet, dairy, fruit, snaks, drink) VALUES (nextval('serial'),?,?,?,?,?,?,?,?)";
		   PreparedStatement prepared_stmt_p = c.prepareStatement(SQL_INSERT_PERSONAL);
		   prepared_stmt_p.setInt(1, user_id);
		   prepared_stmt_p.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
		   prepared_stmt_p.setInt(3, user.getWater_usage());
		   prepared_stmt_p.setInt(4, user.getDiet());
		   prepared_stmt_p.setInt(5, user.getDairy());
		   prepared_stmt_p.setInt(6, user.getFruit());
		   prepared_stmt_p.setInt(7, user.getSnaks());
		   prepared_stmt_p.setInt(8, user.getDrinks());
		   int row_p = prepared_stmt_p.executeUpdate();
		   System.out.println(row_p);
		   
		   c.close();
	   } catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
	   }
	   System.out.println("Successfully loaded values into table");*/
	   
	   return "carbon_cal";
   }
   
   

   @RequestMapping("/registerForm")
   public ModelAndView saveRegister(Registration register){
	   ModelAndView model	=	new ModelAndView("RegistrationSuccess");
	   model.addObject("register", register);
	   Connection c = null;
	   try {
		   System.out.println("In try block");
		   //connect to the database
		   c = DriverManager.getConnection("jdbc:postgresql://juggernauts.postgres.database.azure.com:5432/postgres?user=app_owner@juggernauts&password=app_owner#&sslmode=require");
		   System.out.println("connection established");
		   final String SQL_INSERT_ACCOUNT = "INSERT INTO user_account (login_type_id, user_name, user_email, user_password) VALUES (?,?,?,?)";
		   PreparedStatement prepared_stmt_a = c.prepareStatement(SQL_INSERT_ACCOUNT);
		  if(register.getUser().equals("Organization"))
			  	prepared_stmt_a.setInt(1, 3);
		  	else
		  		prepared_stmt_a.setInt(1, 2);
		   prepared_stmt_a.setString(2, register.getUsername());
		   prepared_stmt_a.setString(3, register.getEmail());
		   prepared_stmt_a.setString(4, register.getPassword());
		   int row_a = prepared_stmt_a.executeUpdate();
		   System.out.println(row_a);
	   } catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
	   }
	   
	   System.out.println("Successfully loaded registration values into table");
	   return model;
   }
   
   @RequestMapping("/loggedIn")
   public ModelAndView afterLogin(Login login){
	   
	   ModelAndView model = null;
	   
	   if((login.getEmail()).equals("admin@db")){
		   model = new ModelAndView("carbon_cal");
	   }
	   else{
		   model = new ModelAndView("login");
	   }
	  
	  
	   
	  /* System.out.println(login.getEmail());
	   Connection c = null;
	   Statement stmt = null;
	   
	   try {
		   System.out.println("In try block");
		   //connect to the database
		   c = DriverManager.getConnection("jdbc:postgresql://juggernauts.postgres.database.azure.com:5432/postgres?user=app_owner@juggernauts&password=app_owner#&sslmode=require");
		   System.out.println("connection established");
			 select *From user_account where user_name = 'test2'; 
		   final String SQL_SEARCH = "select * from user_account where user_email ='"+ login.getEmail()+"'";
		   System.out.println(SQL_SEARCH);
		   stmt = c.createStatement();
		   ResultSet rs = stmt.executeQuery(SQL_SEARCH);
		   System.out.println(rs);
		   if(rs.next()) {
			  
			   model = new ModelAndView("carbon_cal");
			   model.addObject("login", login);
			   
			   //log user_stats
			   final String SQL_FIND = "select user_id from user_account where user_name ='"+ login.getEmail()+"'";
			   System.out.println(SQL_FIND);
			   stmt = c.createStatement();
			   ResultSet res = stmt.executeQuery(SQL_FIND);
			   
			   if(res.next()) {				   
				  int user_id = rs.getInt("user_id");
				  final String SQL_INSERT_STAT = "INSERT INTO user_stats (user_id, login_time) VALUES (?,?)";
				  PreparedStatement prepared_stmt_s = c.prepareStatement(SQL_INSERT_STAT);		   
				  // user_stat
				  prepared_stmt_s.setInt(1, user_id);
				  prepared_stmt_s.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
				  prepared_stmt_s.executeUpdate();
			   }
			   
			   String password = rs.getString("user_password");
			   if(password.equals(login.getPassword())) {
				   System.out.println("Password Matched");
			   }else {
				   model = new ModelAndView("login");
			   }

		   }else {
			   
			   model = new ModelAndView("login");
			   
		   }
		   
	   } catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
	   }
	   System.out.println("checked username in the database");
	  
	   model.addObject("message", "user name/password wrong, Please try again");*/
	   model.addObject("message", "user name/password wrong, Please try again");
	   return model;
   }
   @RequestMapping("/audio")
   public String audio() {
      return "audio";
   }
   @RequestMapping("/video")
   public String video() {
      return "video";
   }
   @RequestMapping("/challenge")
   public String Challenge() {
      return "challenge";
   }

}

/*package com.db.hackathon.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.db.hackathon.model.Login;
import com.db.hackathon.model.Registration;
import com.db.hackathon.model.User;


@Controller
public class HackThonController {
	
	@Autowired
	private HackathonApplicationDAO hackathonApplicationDAO;
	

	Connection c = null;
	Statement stmt = null;
	String url	= jdbc:postgresql://juggernauts.postgres.database.azure.com:5432/postgres?user=app_owner@juggernauts&password=app_owner#&sslmode=require";
   @RequestMapping("/")
   public String root() {
      return "index";
   }
 
   @RequestMapping("/index")
   public String index() {
      return "index";
   }
   @RequestMapping("/login")
   public String login() {
      return "login";
   }
   @RequestMapping("/invest")
   public String invest() {
      return "invest";
   }
   @RequestMapping("/investsubmit")
   public String investSubmit() {
      return "invest";
   }
   @RequestMapping("/registration")
   public String register() {
      return "registration";
   }
   @RequestMapping("/carbon")
   public String carbon() {
      return "carbon_cal";
   }
   @RequestMapping("/donate")
   public String donate() {
      return "donate";
   }
   @RequestMapping("/donateSubmit")
   public String donatesubmit() {
      return "donate";
   }
   @RequestMapping("/carbonCal")
   public String carbon_val(User user){
	   System.out.println(user.getEmail());
	   System.out.println("helloooo --->" + user.getElectricity());
	   
	   int user_id = 0;

	   try {
		   System.out.println("In try block");
		   //connect to the database
		   c = DriverManager.getConnection("jdbc:sqlserver://juggernautssql.database.windows.net:1433;database=SQL;user=admin1@juggernautssql;password=Juggernauts!;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

		   System.out.println("connection established");
		   
		   final String SQL_FIND = "select user_id from user_account where user_name ='"+ user.getEmail()+"'";
		   System.out.println(SQL_FIND);
		   stmt = c.createStatement();
		   ResultSet rs = stmt.executeQuery(SQL_FIND);
		   if(rs.next()) {
			  user_id = rs.getInt("user_id");
		   }


		   final String SQL_INSERT_HOUSE = "INSERT INTO user_house (id, userid, created, electricity, natural_gas, heating_oil, coal, propane, wood) VALUES (nextval('serial'),?,?,?,?,?,?,?,?)";
		   PreparedStatement prepared_stmt_h = c.prepareStatement(SQL_INSERT_HOUSE);		   
		   
		   // user_house
		   prepared_stmt_h.setInt(1, user_id);
		   prepared_stmt_h.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
		   prepared_stmt_h.setInt(3, user.getElectricity());
		   prepared_stmt_h.setInt(4, user.getNatural_gas());
		   prepared_stmt_h.setInt(5, user.getHeating_oil());
		   prepared_stmt_h.setInt(6, user.getCoal());
		   prepared_stmt_h.setInt(7, user.getPropane());
		   prepared_stmt_h.setInt(8, user.getWood());
		   int row_h = prepared_stmt_h.executeUpdate();
		   System.out.println(row_h);
		   
		   // user_transport
		   final String SQL_INSERT_TRANSPORT = "INSERT INTO user_transport (id, userid, created, vehicle_type, Mileage, LPG) VALUES (nextval('serial'),?,?,?,?,?)";
		   PreparedStatement prepared_stmt_t = c.prepareStatement(SQL_INSERT_TRANSPORT);
		   prepared_stmt_t.setInt(1, user_id);
		   prepared_stmt_t.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
		   prepared_stmt_t.setString(3, user.getVehicle_type());
		   prepared_stmt_t.setInt(4, user.getMileage());
		   prepared_stmt_t.setInt(5, user.getLpg());
		   int row_t = prepared_stmt_t.executeUpdate();
		   System.out.println(row_t);
		   
		   
		   // user_personal
		   final String SQL_INSERT_PERSONAL = "INSERT INTO user_personal (id, userid, created, water_usage, diet, dairy, fruit, snaks, drink) VALUES (nextval('serial'),?,?,?,?,?,?,?,?)";
		   PreparedStatement prepared_stmt_p = c.prepareStatement(SQL_INSERT_PERSONAL);
		   prepared_stmt_p.setInt(1, user_id);
		   prepared_stmt_p.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
		   prepared_stmt_p.setInt(3, user.getWater_usage());
		   prepared_stmt_p.setInt(4, user.getDiet());
		   prepared_stmt_p.setInt(5, user.getDairy());
		   prepared_stmt_p.setInt(6, user.getFruit());
		   prepared_stmt_p.setInt(7, user.getSnaks());
		   prepared_stmt_p.setInt(8, user.getDrinks());
		   int row_p = prepared_stmt_p.executeUpdate();
		   System.out.println(row_p);
		   
		   c.close();
	   } catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
	   }
	   System.out.println("Successfully loaded values into table");
	   
	   return "carbon_sucess";
   }
   
   

   @RequestMapping("/registerForm")
   public ModelAndView saveRegister(Registration register){
	   ModelAndView model	=	new ModelAndView("RegistrationSuccess");
	   model.addObject("register", register);
	   Connection c = null;
	   try {
		   System.out.println("In try block");
		   //connect to the database
		   c = DriverManager.getConnection("jdbc:sqlserver://juggernautssql.database.windows.net:1433;database=SQL;user=admin1@juggernautssql;password=Juggernauts!;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

		   System.out.println("connection established"+c);
		   System.out.println(register.getUser());
		   System.out.println(register.getName());
		   System.out.println(register.getEmail());
		   System.out.println(register.getPassword());
		  
		   
		   final String SQL_INSERT_ACCOUNT = "INSERT INTO user_account (user_id, login_type_id, user_name, user_email, user_password) VALUES (?,?,?,?,?)";
		   PreparedStatement prepared_stmt_a = c.prepareStatement(SQL_INSERT_ACCOUNT);
		   prepared_stmt_a.setInt(1, 2);
		  if(register.getUser().equals("Organization"))
			  	prepared_stmt_a.setInt(2, 3);
		  	else
		  		prepared_stmt_a.setInt(2, 2);
		   prepared_stmt_a.setString(3, register.getUsername());
		   prepared_stmt_a.setString(4, register.getEmail());
		   prepared_stmt_a.setString(5, register.getPassword());
		   int row_a = prepared_stmt_a.executeUpdate();
		   System.out.println(row_a);
		   c.close();
	   } catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
	   }
	   
	   System.out.println("Successfully loaded registration values into table");
	   return model;
   }
   
   @RequestMapping("/loggedIn")
   public ModelAndView afterLogin(Login login){
	   System.out.println(login.getEmail());
	   Connection c = null;
	   Statement stmt = null;
	   ModelAndView model = null;
	   try {
		   System.out.println("In try block");
		   //connect to the database
		   c = DriverManager.getConnection("jdbc:sqlserver://juggernautssql.database.windows.net:1433;database=SQL;user=admin1@juggernautssql;password=Juggernauts!;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;");

		   System.out.println("connection established");
			 select *From user_account where user_name = 'test2'; 
		   final String SQL_SEARCH = "select * from user_account where user_email ='"+ login.getEmail()+"'";
		   System.out.println(SQL_SEARCH);
		   stmt = c.createStatement();
		   ResultSet rs = stmt.executeQuery(SQL_SEARCH);
		   System.out.println(rs);
		   if(rs.next()) {
			  
			   model = new ModelAndView("carbon_cal");
			   model.addObject("login", login);
			   
			   //log user_stats
			   final String SQL_FIND = "select user_id from user_account where user_name ='"+ login.getEmail()+"'";
			   System.out.println(SQL_FIND);
			   stmt = c.createStatement();
			   ResultSet res = stmt.executeQuery(SQL_FIND);
			   
			   if(res.next()) {				   
				  int user_id = rs.getInt("user_id");
				  final String SQL_INSERT_STAT = "INSERT INTO user_stats (user_id, login_time) VALUES (?,?)";
				  PreparedStatement prepared_stmt_s = c.prepareStatement(SQL_INSERT_STAT);		   
				  // user_stat
				  prepared_stmt_s.setInt(1, user_id);
				  prepared_stmt_s.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
				  prepared_stmt_s.executeUpdate();
				  
			   }
			   
			   String password = rs.getString("user_password");
			   if(password.equals(login.getPassword())) {
				   System.out.println("Password Matched");
			   }else {
				   model = new ModelAndView("login");
			   }

		   }else {
			   
			   model = new ModelAndView("login");
			   
		   }
		   c.close();
	   } catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
	   }
	   System.out.println("checked username in the database");
	  
	   model.addObject("message", "user name/password wrong, Please try again");
	   return model;
   }

}
*/